document.addEventListener("DOMContentLoaded", () => {
  const toggleBtn = document.getElementById("toggle-ivi");

  function actualizarBoton(estado) {
    toggleBtn.textContent = estado ? "TERMINAR" : "INICIAR";
  }

  chrome.storage.local.get("ivi_chatbot_enabled", (result) => {
    const estadoActual = result.ivi_chatbot_enabled === true;
    actualizarBoton(estadoActual);
  });

  toggleBtn.addEventListener("click", () => {
    chrome.storage.local.get("ivi_chatbot_enabled", (result) => {
      const estadoAnterior = result.ivi_chatbot_enabled === true;
      const nuevoEstado = !estadoAnterior;

      chrome.storage.local.set({ ivi_chatbot_enabled: nuevoEstado }, () => {
        actualizarBoton(nuevoEstado);
      });
    });
  });
});
